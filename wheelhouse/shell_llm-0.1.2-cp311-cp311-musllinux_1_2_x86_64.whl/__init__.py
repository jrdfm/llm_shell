"""
LLM Shell Assistant - An intelligent shell wrapper with LLM-powered features.
"""

__version__ = "0.1.1" 